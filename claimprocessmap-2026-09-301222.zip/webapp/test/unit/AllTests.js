sap.ui.define([
	"com/sap/claimprocessmap/claimprocessmap/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
