sap.ui.define([
    "sap/ui/core/mvc/Controller"
], (Controller) => {
    "use strict";

    return Controller.extend("com.sap.claimprocessmap.claimprocessmap.controller.View1", {
        onInit() {
        }
    });
});